import qualified Language.Nano.Types  as Nano
import qualified Language.Nano.Eval   as Nano
import           Language.Nano.Repl
import           Text.Printf
import           GHC.IO.Encoding
import Language.Nano.Eval (defsFile)

-- https://util.unicode.org/UnicodeJsps/character.jsp?a=03BB
lambda :: String
lambda = "\x03BB"

main :: IO ()                             
main = do
  setLocaleEncoding utf8
  putStrFlush welcome
  repl Nano.prelude 0

repl :: Nano.Env -> Int -> IO ()
repl env n = do
  putStrFlush (lambda ++ " [" ++ show n ++ "] ")
  input <- getLine
  case strCmd input of
    CQuit       -> doQuit
    CEval s     -> do
      result <- doEval env s
      repl env (n + 1)
    CRun file   -> do
      doRun file
      repl env (n + 1)
    CLoad file  -> do 
      defs <- doLoad file
      putStrLn ("definitions: " ++ unwords (map fst defs)) ---unwords concatenates list into a single string
      repl defs (n + 1)
    CUnknown    -> do
      doUnknown
      repl env (n + 1)

--------------------------------------------------------------------------------
-- | Some useful functions 
--------------------------------------------------------------------------------
-- putStr   :: String -> IO ()
-- hFlush   :: 
-- putStrLn :: String -> IO ()
-- getLine  :: IO String 

